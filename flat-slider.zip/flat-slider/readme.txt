=== Bootstrap slider By Clarion===

/**
 * Plugin Name:		   Bootstrap Flat File slider
 * Plugin URI:		   http://clariontechnologies.co.in
 * Description:		   Twitter Bootstrap based  professional WordPress  carousel Flat slider plugin.
 * Version: 		   1.0.0
 * Author: 			   clarion 
 * Author URI: 		   http://clariontechnologies.co.in
 */
 
 This Plugin is used as a flat file slider - users can Add/Edit/Delete slides and change their disply position 
 
 To fetch the slider at from end - use shortcode <?php echo do_shortcode('[flat-slider]');?>
